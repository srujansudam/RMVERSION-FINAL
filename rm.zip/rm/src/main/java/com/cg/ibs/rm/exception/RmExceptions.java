package com.cg.ibs.rm.exception;

public class RmExceptions extends Exception{
	public RmExceptions(String message)
	{
		super(message);
	}
}
