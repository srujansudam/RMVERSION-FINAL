package com.cg.ibs.rm.ui;

public enum Type {
	SELFINSAME, SELFINOTHERS, OTHERSINSAME, OTHERSINOTHERS
}
